package com.example.quizgame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class QuizInstructionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_instructions);

        // Initialize the start quiz button
        Button startQuizButton = findViewById(R.id.start_quiz);

        // Set an OnClickListener on the startQuizButton
        startQuizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the QuizActivity
                Intent startQuizIntent = new Intent(QuizInstructionsActivity.this, QuizActivity.class);
                startActivity(startQuizIntent);
            }
        });
    }
}
