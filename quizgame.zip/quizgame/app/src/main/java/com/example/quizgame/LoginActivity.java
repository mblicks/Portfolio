package com.example.quizgame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Assuming these views are used for some purpose in your code, ensure they are correctly cast and used.
        // For example, EditText email = findViewById(R.id.email);
        // EditText password = findViewById(R.id.password);

        Button loginButton = findViewById(R.id.login); // If this is a button in your layout
        Button registerButton = findViewById(R.id.register);

        // Assuming loginButton is intended for login purpose, you might want to add an OnClickListener here as well.

        registerButton.setOnClickListener(view -> startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));
    }
}
