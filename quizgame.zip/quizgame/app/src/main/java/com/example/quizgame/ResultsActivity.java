package com.example.quizgame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultsActivity extends AppCompatActivity {

    private TextView scoreTextView;
    private Button retakeQuizButton, mainMenuButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        // Initialize views
        scoreTextView = findViewById(R.id.scoreTextView);
        retakeQuizButton = findViewById(R.id.retakeQuizButton);
        mainMenuButton = findViewById(R.id.mainMenuButton);

        // Retrieve the score from Intent
        int score = getIntent().getIntExtra("SCORE", 0);
        int totalQuestions = getIntent().getIntExtra("TOTAL_QUESTIONS", 0);

        // Set the score text
        scoreTextView.setText(String.format("Your Score: %d/%d", score, totalQuestions));

        // Set onClickListener for retakeQuizButton
        retakeQuizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to start QuizActivity
                Intent intent = new Intent(ResultsActivity.this, QuizActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // Set onClickListener for mainMenuButton
        mainMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to go back to the main menu (assuming MainActivity is your main menu)
                Intent intent = new Intent(ResultsActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Clears the activity stack
                startActivity(intent);
                finish();
            }
        });
    }
}
