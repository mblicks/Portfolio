package com.example.quizgame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class QuizActivity extends AppCompatActivity {

    private RadioGroup radioGroup;

    private final String[] options;
    private final int correctAnswerIndex = 0; // Index of the correct answer in the options array
    private int score = 0; // Track the user's score

    public QuizActivity() {
        options = new String[]{"Paris", "London", "Berlin", "Madrid"};
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        TextView questionTextView = findViewById(R.id.question);
        radioGroup = findViewById(R.id.answers);
        Button confirmButton = findViewById(R.id.confirm_answer);

        // Set the question text
        // Example question. You'll likely have a list or array of questions in a real app.
        String question = "What is the capital of France?";
        questionTextView.setText(question);

        // Populate the RadioGroup with the options
        for (int i = 0; i < getOptions().length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(getOptions()[i]);
            radioButton.setId(View.generateViewId());
            radioGroup.addView(radioButton);
        }

        // Set an OnClickListener on the confirmButton
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                RadioButton selectedRadioButton = findViewById(selectedId);
                int selectedIndex = radioGroup.indexOfChild(selectedRadioButton);

                // Check if the selected answer is correct
                if (selectedIndex == correctAnswerIndex) {
                    score++;
                }

                // Proceed to the next question or finish the quiz
                showNextQuestion();
            }
        });
    }

    private void showNextQuestion() {
        // This method should update the UI with the next question or finish the quiz
        // For simplicity, this example will directly move to the ResultsActivity

        Intent resultIntent = new Intent(QuizActivity.this, ResultsActivity.class);
        resultIntent.putExtra("SCORE", score);
        // Assuming total questions is 1 for this example. Update accordingly.
        resultIntent.putExtra("TOTAL_QUESTIONS", 1);
        startActivity(resultIntent);
        finish();
    }

    public String[] getOptions() {
        return options;
    }
}
