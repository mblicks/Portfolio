package com.example.quizgame;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private static void onClick(View view) {
        // Proceed with registration logic
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        findViewById(R.id.first_name);
        findViewById(R.id.last_name);
        findViewById(R.id.email);
        findViewById(R.id.password);
        Button registerButton = findViewById(R.id.register);

        registerButton.setOnClickListener(RegisterActivity::onClick);
    }

    private boolean isValidInput() {
        // Implement validation logic here
        return true;
    }
}
